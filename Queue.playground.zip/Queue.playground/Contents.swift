import Foundation

func insertSorted(_ queue: inout [Int], _ element: Int) {
    if queue.isEmpty || queue.last! <= element {
        queue.append(element)
        return
    }
    let last = queue.removeLast()

    insertSorted(&queue, element)

    queue.append(last)
}

func sortQueue(_ queue: inout [Int]) {

    if queue.count <= 1 {
        return
    }

    let front = queue.removeFirst()
    
    sortQueue(&queue)

    insertSorted(&queue, front)
}

var queue = [3, 1, 4, 10, 5, 9, 2, -2, -5, 0]
sortQueue(&queue)
print("Sorted queue:", queue)
